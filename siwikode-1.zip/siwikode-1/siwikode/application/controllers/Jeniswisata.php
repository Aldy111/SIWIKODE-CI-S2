<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jeniswisata extends CI_Controller {

    public function index()
	{
		$this->load->model('jeniswisata_model','jw');
        $data['list_jw']=$this->jw->getAll();

        $this->load->view('header');
        $this->load->view('jenis_wisata/index',$data);
        $this->load->view('footer');

        //$this->load->view('tamplate');
	}
    public function create()
    {
        $data['']='';
        $this->load->view('header');
        $this->load->view('jenis_wisata/form',$data);
        $this->load->view('footer');
    }
    public function save()
    {
        $this->load->model('jeniswisata_model','jw');
        $nama_jw = $this->input->post('nama_jw');
        $idedit = $this->input->post('idedit');
        $data_jw['nama_jw']=$nama_jw;// ?2
        
        if(!empty($idedit)){//update
            $data_jw['id']=$idedit;//?3
            $this->jw->update($data_jw);
        }else{//tambah data baru
            $this->jw->simpan($data_jw);
        }
        redirect('jeniswisata','refresh');
        /* $data['list_dosen']=$this->dosen->getAll();
        $this->load->view('header');
        $this->load->view('dosen/index',$data);
        $this->load->view('footer'); */
    }


    public function edit($id){
        $this->load->model('jeniswisata_model','jw');
        $obj_jw = $this->jw->findById($id);
        $data['objjw']=$obj_jw;


        $this->load->view('header');
        $this->load->view('jenis_wisata/edit',$data);
        $this->load->view('footer');
    }


    public function delete($id){

        $this->load->model('jeniswisata_model','jw');
        $data_jw['id']=$id;
        $validate = $this->jw->validate($id);
        
	    if(count($validate) > 0){
            
            echo "<script>alert('Data Tidak Dapat Di Hapus ')</script>";
            echo "<meta http-equiv='refresh' content='0;url=".base_url()."index.php/jeniswisata'>";
	        
	        
	    }else{
            // var_dump($validate);
            $this->jw->delete($data_jw);
            redirect('jeniswisata','refresh');
	    }
        //pastikan role diperkenankan
        
        
    }
}