<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Login_user_model');
    }
    public function index() {
        $this->load->view('login/sign');
    }

    public function regist() {
        $this->load->view('login/regist');
    }
    
    public function act_login(){
	    $username = $this->input->post('email',TRUE);
	    $password = md5($this->input->post('pass',TRUE));
	    $validate = $this->Login_user_model->validate($username,$password);
        
	    if($validate->num_rows() > 0){
	        $data  			= $validate->row_array();
	        $id_user 		= $data['id_user'];
	        $nama  		    = $data['nama'];
	        $email 			= $data['email'];
	        $phone 			= $data['phone'];
   	        $role 		    = $data['role'];

	        
	        $sesdata = array(
	            'id_user'    => $id_user,
	            'nama'       => $nama,
	            'email'      => $email,
	            'phone'      => $phone,
	            'role'       => $role,
	            'logged_in' => TRUE
	        );
	        $this->session->set_userdata($sesdata);
	        redirect(base_url("index.php/dashboard/index"));
	        
	    }else{
            // var_dump($validate);
	       echo "<script>alert('Login Gagal ')</script>";
        echo '<meta http-equiv="refresh" content="0;url='.base_url().'index.php/login">';
	    }

	}

    public function simpan_regist()
    {
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $pass =  md5($this->input->post('pass'));
        $role = "USER";
        date_default_timezone_set('asia/jakarta');
        $registDate = date('Y-m-d H:i:s');
        $lastLog ="0000-00-00 00:00:00";

        $query_chek =  $this->Login_user_model->chek($email,$phone);

        if (count($query_chek) > 0) {
            echo "<script>alert('Data Nomor handphone atau email sudah digunakan')</script>";
            echo '<meta http-equiv="refresh" content="0;url='.base_url().'index.php/login/regist">';
        }else{

        $data = array(
            'nama' => $nama,
            'email' => $email,
            'phone' => $phone,
            'password' => $pass,
            'role' => $role,
            'lastLog' => $lastLog,
            'registDate' => $registDate
            );
        $this->Login_user_model->save_data($data);    
        echo "<script>alert('Data Berhasil Disimpan silahkan Login')</script>";
        echo '<meta http-equiv="refresh" content="0;url='.base_url().'index.php/login">';
        }
    }
    public function logout(){
        
        $user = $this->session->userdata('id_user');
        date_default_timezone_set('asia/jakarta');
        $date = date('Y-m-d H:i:s');
        $data = array(
            'lastLog' => $date
        );
        $this->Login_user_model->logData($data,$user);
        $this->session->sess_destroy();
        redirect('Client');

    }
}