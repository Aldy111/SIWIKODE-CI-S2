<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profesi extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->model('profesi_model','profesi');
        $data['list_profesi']=$this->profesi->getAll();

        $this->load->view('header');
        $this->load->view('profesi/index',$data);
        $this->load->view('footer');
	}
    
    public function create()
    {
        $data['']='';
        $this->load->view('header');
        $this->load->view('profesi/form',$data);
        $this->load->view('footer');
    }

    public function save()
    {
        $this->load->model('profesi_model','profesi');

        $nama_profesi = $this->input->post('nama_profesi');
        $idedit = $this->input->post('idedit');

        $data_profesi['nama_profesi']=$nama_profesi;// ?1

        
        
        if(!empty($idedit)){//update
            $data_profesi['id']=$idedit;//?2
            $this->profesi->update($data_profesi);
        }else{//tambah data baru
            $this->profesi->simpan($data_profesi);
        }
        redirect('profesi','refresh');

    }


    public function edit($id){
        $this->load->model('profesi_model','profesi');
        $obj_pro = $this->profesi->findById($id);
        $data['objpro']=$obj_pro;


        $this->load->view('header');
        $this->load->view('profesi/edit',$data);
        $this->load->view('footer');
    }

    public function delete($id){

        $this->load->model('profesi_model','profesi');
        $data_pro['id']=$id;
        $validate = $this->profesi->validate($id);
        
	    if(count($validate) > 0){
            
            echo "<script>alert('Data Tidak Dapat Di Hapus ')</script>";
            echo "<meta http-equiv='refresh' content='0;url=".base_url()."index.php/profesi'>";
	        
	        
	    }else{
            // var_dump($validate);
            $this->profesi->delete($data_pro);
            redirect('profesi','refresh');
	    }
        //pastikan role diperkenankan
        
        
    }

}
