<?php
class Profesi_model extends CI_Model{

    public function getAll(){
        //SELECT * FROM jenis_kuliner;
        $query = $this->db->get('profesi');
        return $query;
    }


    public function findById($id){
        //SELECT * FROM jenis_wisata WHERE id=1;
        $query = $this->db->get_where('profesi', array('id' => $id));
        return $query->row();
    }

    public function simpan($data)
    {
        // INSERT INTO jenis_wisata (nama) VALUES ('budi');
        $sql = "INSERT INTO profesi (nama_profesi) VALUES (?)";
        //$this->db->query($sql, array('111','budi'));
        $this->db->query($sql,$data);
    }
    

    public function update($data){
        //UPDATE dosen SET nidn='1111',nama='aldy prayogo s.kom' WHERE id=1;
        $sql = "UPDATE profesi SET nama_profesi=? WHERE id=?";
        $this->db->query($sql, $data);
    }


    public function delete($data){
        //DELETE FROM dosen WHERE id=1;
        $sql = "DELETE FROM profesi WHERE id=?";
        $this->db->query($sql, $data);
    }
    function validate($id){
        $this->db->select('*');
        $this->db->from('profesi');
        $this->db->join('testimoni','testimoni.profesi_id = profesi.id');
        $this->db->where('id',$id);
        $result = $this->db->get();
        return $result->result();
    }


}