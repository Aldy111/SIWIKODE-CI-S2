<?php
class Login_user_model extends CI_Model{

    public function save_data($data)
    {
        $this->db->insert('user', $data);
    }
    public function chek($email,$phone){
			$this->db->select('*');
			$this->db->from('user');
			$this->db->where('email',$email);
			$this->db->or_where ('phone',$phone);
			return $this->db->get()->result();
    }
    function validate($username,$password){
        $this->db->where('email',$username);
        $this->db->where('password',$password);
        $result = $this->db->get('user');
        return $result;
    }
    public function logData($data,$user)
    {
        $this->db->where('id_user',$user);
        $this->db->update('user',$data);

    }

}