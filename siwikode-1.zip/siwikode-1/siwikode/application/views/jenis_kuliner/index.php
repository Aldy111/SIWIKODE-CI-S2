
<script>
    function hapusWisata(pesan)  {
        if(confirm(pesan)){
            return true;
        }else{
            return false;
        }
    }
</script>
    <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="col-md-12"></div>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h1>Daftar Jenis Kuliner</h1>
                            <a href="<?=base_url()?>index.php/jeniskuliner/create" class="btn btn-primary btn-sm active" role="button" aria-pressed="true"><i class="fa fa-plus"></i>Tambah Data</a></br>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Jenis Kuliner</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nomor = 1;
                                    foreach ($list_jk->result() as $row) 
                                    
                                    {
                                        
                                        echo '<tr><td>'.$nomor.'</td>';
                                        echo '<td>'.$row->nama_jk.'</td>';
                                        
                                        //echo '<td>view | edit | delete</td>';
                                        echo '<td>';
                                        echo
                                        '<a href="'.base_url().'index.php/jeniskuliner/edit/'.$row->id.'" class="btn btn-warning btn-sm active" role="button" aria-pressed="true"><i class="fa fa-pencil"></i></a>
                                        <a href="'.base_url().'index.php/jeniskuliner/delete/'.$row->id.'" class="btn btn-danger btn-sm active" role="button" aria-pressed="true"onclick="return hapusWisata(\'data jenis kuliner '.$row->nama_jk.' Yakin mau dihapus ??\')"><i class="fa fa-trash"></i></a>
                                        </td>';
                                        echo '</tr>';
                                        $nomor++;
                                    }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->



