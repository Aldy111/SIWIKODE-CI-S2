<?php $role = $this->session->userdata('role');
 $nama = $this->session->userdata('nama');
 $email = $this->session->userdata('email');
 $phone = $this->session->userdata('phone');
 ?>
<?php if($role == '' || $role == null){
  ?>
  <script type="text/javascript">
    alert('anda harus login'); window.location = '<?php echo base_url() ?>index.php/Login/index'
  </script>
  <?php
} ?>

  <?php 
  // Menus
  if($role == 'ADMIN'){
        $menu['Dashboard']     = "". base_url()."index.php/Dashboard";
        $menu['jenis kuliner']  = "". base_url()."index.php/jeniskuliner";
        $menu['jenis wisata']   = "". base_url()."index.php/jeniswisata";
        $menu['profesi']       = "". base_url()."index.php/profesi";
        $menu['testimoni']     = "". base_url()."index.php/Testimoni";
        $menu['wisata']        = "". base_url()."index.php/wisata";
        $menu['logout']        = "". base_url()."index.php/Login/logout";
  }elseif($role == 'USER'){
        $menu['Dashboard']     = "". base_url()."index.php/dashboard";
        $menu['testimoni']     = "". base_url()."index.php/Testimoni";
        $menu['wisata']        = "". base_url()."index.php/wisata";
  }
  ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Siwikode</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url() ?>public/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?php echo base_url() ?>public/css/simple-sidebar.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>public/Login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
</head>

<body class="sb-nav-fixed">

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">SIWIKODE</div>
      <div class="list-group list-group-flush">
      <?php 
      foreach($menu as $MenuName =>  $urlMenu)
        {
          echo '<a href="' . $urlMenu .'"class="nav-link list-group-item list-group-item-action bg-light">'.$MenuName.'</a>';
        }
      ?>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-sm btn-warning" id="menu-toggle"><i class="fa fa-exchange"></i></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fa fa-user"></i> <?php echo $nama; ?>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a href="<?php echo base_url() ?>index.php/Login/logout" onClick="confirm('Yakin Ingin Logout?')" class="dropdown-item"> Logout</a>
            </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">