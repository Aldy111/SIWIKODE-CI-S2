<h1>Form wisata</h1>
<?php echo form_open('wisata/save_data_edit');?>
<div class="col-md-12">
<?php foreach($idedit as $data):?>
  <input id="nama" name="wisata_id" type="hidden" class="form-control" value='<?php echo $data->id_wisata ?>'>
  <div class="form-group row">
      <div class="col-8">
          <label for="nama" class=" col-form-label">Nama Wisata</label> 
          <input id="nama_wisata" name="nama_wisata" type="text" value='<?php echo $data->nama_wisata?>' class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Jenis Wisata</label> 
          <select name="jenis_wisata_id" id="" class="form-control" required>
          <option value="">--Pilih--</option>
            <?php foreach($list_jw as $data2):?>
            <option value="<?php echo $data2->id;?>"><?php echo $data2->nama_jw;?></option>
            <?php endforeach;?>
          </select>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Email</label> 
          <input id="nama" name="email" type="text" value='<?php echo $data->email ?>'  class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Fasilitas</label> 
          <input id="nama" name="fasilitas" type="text" value='<?php echo $data->fasilitas ?> ' class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">bintang</label> 
          <select name="bintang" id="" value='<?php echo $data->bintang ?> ' class="form-control" required>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Kontak</label> 
          <input id="nama" name="kontak" type="text" value='<?php echo $data->kontak ?>'class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Alamat</label> 
          <input id="nama" name="alamat" type="text" value='<?php echo $data->alamat ?> ' class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Location Google Maps</label> 
          <input id="nama" name="latlong" type="text" value='<?php echo $data->latlong ?> ' class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Web</label> 
          <input id="nama" name="web" type="text" value='<?php echo $data->web ?> ' class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Jenis Kuliner</label> 
          <select name="jenis_kuliner_id" id="" class="form-control" required>
          <option value="">--Pilih--</option>
            <?php foreach($list_jk as $data2):?>
            <option value="<?php echo $data2->id;?>"><?php echo $data2->nama_jk;?></option>
            <?php endforeach;?>
          </select>
      </div>
      <div class="col-8">
      <label for="nama" class=" col-form-label">Deskripsi</label> 
      <textarea name="deskripsi" id="" cols="30" rows="10" class="form-control"><?php echo $data->deskripsi;?></textarea>
      </div>
    <div class="col-8">
        <button name="submit" type="submit" class="btn btn-primary" style="margin-top:10px">Submit</button>
    </div>
  <?php endforeach;?>
</div>
<?php echo form_close()?>
