<?php $role = $this->session->userdata('role');?>
<?php $user_id = $this->session->userdata('id_user') ?>
<script>
    function hapusWisata(pesan)  {
        if(confirm(pesan)){
            return true;
        }else{
            return false;
        }
    }
</script>
    <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="col-md-12"></div>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h1>Daftar Wisata</h1>
                            <a href="<?=base_url()?>index.php/wisata/create" class="btn btn-primary btn-sm active" role="button" aria-pressed="true" ><i class="fa fa-plus"></i>Tambah Data</a></br>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Wisata</th>
                                            <th>Deskripsi</th>
                                            <th>fasilitas</th>
                                            <th>Bintang</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                
                                    <tbody>
                                    <?php
                                    $nomor = 1;
                                    foreach ($list_wisata as $data) 
                                    
                                    {
                                        
                                        echo '<tr><td>'.$nomor.'</td>';
                                        echo '<td>'.$data->nama_wisata.'</td>';
                                        echo '<td>'.$data->deskripsi.'</td>';
                                        echo '<td>'.$data->fasilitas.'</td>';
                                        echo '<td>'.$data->bintang.'</td>';
                                        
                                        //echo '<td>view | edit | delete</td>';
                                        echo '<td>';
                                        // if($data->id_user == $user_id){
                                        // echo' <a href="'.base_url().'index.php/wisata/edit/'.$data->id_wisata.'" class="btn btn-sm btn-warning  active" role="button" aria-pressed="true"><i class="fa fa-pencil"></i></a>';
                                        // echo' <a href="'.base_url().'index.php/wisata/delete/'.$data->id_wisata.'" class="btn btn-sm btn-danger active" role="button" aria-pressed="true"onclick="return hapusWisata(\'Data wisata '.$data->nama_wisata.' Yakin mau dihapus ??\')"><i class="fa fa-trash"></i></a>';
                                        // echo' <a href="'.base_url().'index.php/wisata/detail/'.$data->id_wisata.'" class="btn btn-sm btn-success  active" role="button" aria-pressed="true"><i class="fa fa-search"></i></a>';
                                        // }else{
                                        //     echo'<a href="'.base_url().'index.php/wisata/detail/'.$data->id_wisata.'" class="btn btn-success btn-sm active" role="button" aria-pressed="true"><i class="fa fa-search"></i></a>';
                                        // }
                                        if($role == 'ADMIN'){
                                            if($data->id_user == $user_id){
                                                echo' <a href="'.base_url().'index.php/wisata/edit/'.$data->id_wisata.'" class="btn btn-sm btn-warning  active" role="button" aria-pressed="true"><i class="fa fa-pencil"></i></a>';
                                                echo' <a href="'.base_url().'index.php/wisata/delete/'.$data->id_wisata.'" class="btn btn-sm btn-danger active" role="button" aria-pressed="true"onclick="return hapusWisata(\'Data wisata '.$data->nama_wisata.' Yakin mau dihapus ??\')"><i class="fa fa-trash"></i></a>';
                                                echo' <a href="'.base_url().'index.php/wisata/detail/'.$data->id_wisata.'" class="btn btn-sm btn-success  active" role="button" aria-pressed="true"><i class="fa fa-search"></i></a>';
                                                }else{
                                                    echo' <a href="'.base_url().'index.php/wisata/delete/'.$data->id_wisata.'" class="btn btn-sm btn-danger active" role="button" aria-pressed="true"onclick="return hapusWisata(\'Data wisata '.$data->nama_wisata.' Yakin mau dihapus ??\')"><i class="fa fa-trash"></i></a>';
                                                    echo' <a href="'.base_url().'index.php/wisata/detail/'.$data->id_wisata.'" class="btn btn-sm btn-success  active" role="button" aria-pressed="true"><i class="fa fa-search"></i></a>';
                                                }
                                        
                                        }else if($role == 'USER'){
                                            if($data->id_user == $user_id){
                                                echo' <a href="'.base_url().'index.php/wisata/edit/'.$data->id_wisata.'" class="btn btn-sm btn-warning  active" role="button" aria-pressed="true"><i class="fa fa-pencil"></i></a>';
                                                echo' <a href="'.base_url().'index.php/wisata/delete/'.$data->id_wisata.'" class="btn btn-sm btn-danger active" role="button" aria-pressed="true"onclick="return hapusWisata(\'Data wisata '.$data->nama_wisata.' Yakin mau dihapus ??\')"><i class="fa fa-trash"></i></a>';
                                                echo' <a href="'.base_url().'index.php/wisata/detail/'.$data->id_wisata.'" class="btn btn-sm btn-success  active" role="button" aria-pressed="true"><i class="fa fa-search"></i></a>';
                                                }else{
                                                    echo'<a href="'.base_url().'index.php/wisata/detail/'.$data->id_wisata.'" class="btn btn-success btn-sm active" role="button" aria-pressed="true"><i class="fa fa-search"></i></a>';
                                                }
                                        }

                                        
                                        
                                        echo'</td>';
                                        echo '</tr>';+
                                    
                                        $nomor++;
                                    }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->



