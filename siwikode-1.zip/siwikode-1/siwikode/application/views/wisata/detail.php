

<h1 class="mt-4">Detail Wisata</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Detail Wisata</li>
</ol>
<?php foreach($detail as $data):?>
<div class="row">
<div class="col-12">
  <div class = 'col-lg-12'>
  <img src="data:image/jpeg;base64,<?php echo $data->img ?>"  class="img-fluid" alt="Responsive image">
  </div>
  <br>
  <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63443.405672429406!2d106.79263483299441!3d-6.366493676538825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xd7a63a39c65c9b8c!2sKolam%20Renang%20DTC!5e0!3m2!1sen!2sid!4v1625757484487!5m2!1sen!2sid" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe> -->
  </div>
        <div class="col-12">
          <h3>Detail Informasi</h3>
        </div>
  <div class="col-xl-6">
    <table class="table ">
    <tr>
    <td>Nama Wisata </td><td>:</td>
    <td><?php echo $data->nama_wisata?></td>
    </tr>
    <tr>
    <td>Deskripsi  </td><td>:</td>
    <td><?php echo $data->deskripsi?></td>
    </tr>
    <tr>
    <td>Jenis Wisata </td><td>:</td>
    <td><?php echo $data->nama_jw?></td>
    </tr>
    <tr>
    <td>Fasilitas  </td><td>:</td>
    <td><?php echo $data->fasilitas?></td>
    </tr>
    <tr>
    <td>Bintang  </td><td>:</td>
    <td><?php echo $data->bintang?></td>
    </tr>
    <tr>
    <td>Kontak  </td><td>:</td>
    <td><?php echo $data->kontak?></td>
    </tr>
    <tr>
    <td>Alamat  </td><td>:</td>
    <td><?php echo $data->alamat?></td>
    </tr>
    <!-- <tr>
    <td>Latlong :</td>
    <td></td>
    </tr> -->
    <tr>
    <td>Email  </td><td>:</td>
    <td><?php echo $data->email?></td>
    </tr>
    <tr>
    <td>Web  </td><td>:</td>
    <td><?php echo $data->web?></td>
    </tr>
    <tr>
    <td>Jenis Kuliner  </td><td>:</td>
    <td><?php echo $data->nama_jk?></td>
    </tr>
    </table>
  </div>
  <div class="col-xl-6">
  <?php echo $data->latlong?>
  <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63443.405672429406!2d106.79263483299441!3d-6.366493676538825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xd7a63a39c65c9b8c!2sKolam%20Renang%20DTC!5e0!3m2!1sen!2sid!4v1625757484487!5m2!1sen!2sid" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe> -->
  </div>
  </div>
  </div>
  <?php endforeach;?>

