<h1>Form wisata</h1>
<?php echo form_open_multipart('wisata/save');?>
<div class="col-md-12">
  <div class="form-group row">
      <div class="col-8">
          <label for="nama" class=" col-form-label">Nama Wisata</label> 
          <input id="nama_wisata" name="nama_wisata" type="text" class="form-control" required> 
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Jenis Wisata</label> 
          <select name="jenis_wisata_id" id="" class="form-control"required>
          <option value="">--Pilih--</option>
            <?php foreach($list_jw as $data2):?>
            <option value="<?php echo $data2->id;?>"><?php echo $data2->nama_jw;?></option>
            <?php endforeach;?>
          </select>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Email</label> 
          <input id="nama" name="email" maxlength="45" type="text" class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Fasilitas</label> 
          <input id="nama" name="fasilitas" type="text" class="form-control"required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">bintang</label> 
          <select name="bintang" id="" class="form-control" required>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Kontak</label> 
          <input id="nama" name="kontak" maxlength="15" type="text" class="form-control" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Alamat</label> 
          <input id="nama" name="alamat" type="text" class="form-control" required>
      </div>
      <!--<div class="col-8">-->
      <!--    <label for="nama" class=" col-form-label">Latlong</label> -->
      <!--    <input id="nama" name="latlong" type="text" class="form-control" required>-->
      <!--</div>-->
      <div class="col-8">
          <label for="nama" class=" col-form-label">Location Google Maps</label> 
          <input id="nama" name="latlong" type="text" class="form-control">
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Web</label> 
          <input id="nama" name="web" type="text" class="form-control" maxlength="45" required>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Jenis Kuliner</label> 
          <select name="jenis_kuliner_id" id="" class="form-control" required>
          <option value="">--Pilih--</option>
            <?php foreach($list_jk as $data2):?>
            <option value="<?php echo $data2->id;?>"><?php echo $data2->nama_jk;?></option>
            <?php endforeach;?>
          </select>
      </div>
      <div class="col-8">
        <label for="nama" class=" col-form-label">Deskripsi</label> 
        <textarea name="deskripsi" id="" cols="30" rows="10"class="form-control" required></textarea>
      </div>
      <div class="col-8">
        <label for="nama" class=" col-form-label">Upload foto</label> 
        <input id="nama" name="img" type="file" class="form-control" required>
      </div>
    <div class="col-8">
        <button name="submit" type="submit" class="btn btn-primary " style="margin-top:10px">Submit</button>
    </div>
</div>
<?php echo form_close()?>
