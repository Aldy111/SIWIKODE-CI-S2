<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="<?php echo base_url() ?>onix/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <title>Siwikode</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url() ?>onix/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="<?php echo base_url() ?>public/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> -->



    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url() ?>onix/assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>onix/assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>onix/assets/css/animated.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>onix/assets/css/owl.css">
    
<!--

TemplateMo 565 Onix Digital

https://templatemo.com/tm-565-onix-digital

-->
  </head>
  <style>
    .fa-star{
      color:#ffc107;
    }
    .fa-search{
      color:#ffffff;
    }
    .detail-info{
      color:#ffffff;
    }
  </style>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->
<div id="top">

  <div id="video" class="our-videos section">
    <div class="videos-left-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/videos-left-dec.png" alt="">
    </div>
    <div class="videos-right-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/videos-right-dec.png" alt="">
    </div>
    <div class="container">

    <div class="row">
      <?php foreach($detail_list as $data):?>
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                <div class="col-lg-8">
                  <ul class="nacc">
                    <li class="active">
                      <div>
                        <div class="thumb">
                        <?php echo $data->latlong?>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
                <div class="col-lg-4">
                  <div class="menu">
                    <div class="active">
                      <div class="thumb">
                        <h2>Detail Wisata</h2>
                      <table class="table ">
                      <tr>
                      <td>Nama Wisata </td>
                      <td><?php echo $data->nama_wisata?></td>
                      </tr>
                      <tr>
                      <td>Jenis Wisata  </td>
                      <td><?php echo $data->nama_jw?></td>
                      </tr>
                      <tr>
                      <td>Jenis Kuliner </td>
                      <td><?php echo $data->nama_jk?></td>
                      </tr>
                      <tr>
                      <td>Fasilitas  </td>
                      <td><?php echo $data->fasilitas?></td>
                      </tr>
                      <tr>
                      <td>Bintang  </td>
                      <td>                    
                      <?php for($i=0; $i<$data->bintang; $i++ ){
                      echo '<i class = "fa fa-star"> </i>';
                      } ?></td>
                      </tr>
                      <tr>
                      <td>Kontak  </td>
                      <td><?php echo $data->kontak?></td>
                      </tr>
                      <tr>
                      <td>Alamat  </td>
                      <td><?php echo $data->alamat?></td>
                      </tr>
                      <tr>
                      <td>Email  </td>
                      <td><?php echo $data->email?></td>
                      </tr>
                      <tr>
                      <td>Web  </td>
                      <td><?php echo $data->web?></td>
                      </tr>
                      <tr>
                      <td>Deskripsi  </td>
                      <td><?php echo $data->deskripsi?></td>
                      </tr>
                      </table>
                      </div>
                    </div>
                    <div>
                      <div class="thumb">
                       <img src="data:image/jpeg;base64,<?php echo $data->img ?>" class="image-fluid" alt="">
                      </div>
                    </div>
                  </div>
                </div>                   
              </div>
              <div class="col-lg-12">
                  <h2>Komentar</h2>
                <?php foreach($komen_list as $komen):?>
                  <br>
                  <div class="row">
                    <div class="col-sm-7">
                      <div class="card">
                        <h5 class="card-header"><?php echo $komen->nama?>(<?php echo $komen->nama_profesi?>)</h5>
                        <div class="card-body">
                          <h5 class="card-title">Rating :
                            <?php for($i=0; $i<$komen->rating; $i++ ){
                            echo '<i class = "fa fa-star"> </i>';
                            } ?></h5>
                          <p class="card-text"><?php echo $komen->komentar?></p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php endforeach;?>
                  <br>
                  <div class="col-lg-12">
                    <div class = "row">
                    <div class="col-sm-7">
                  <div class="card">
                    <div class="card-header">
                        Featured
                      </div>
                      <div class="card-body">
                          <h5 class="card-title">Tuliskan komentar kamu</h5>
                          <form action = "<?php echo base_url('index.php/Client/save_data')?>" method="POST">
                          <input type="hidden" name="wisata_id" value="<?php echo $data->id_wisata ?>" class="form-control" placeholder="" >
                          <div class="form-row">
                              <div class="form-group col-md-12">
                                <label for="inputEmail4">Nama</label>
                                <input type="text" name="nama" class="form-control" placeholder="Nama Kamu" required>
                              </div>
                              <div class="form-group col-md-12">
                                <label for="inputPassword4">Email</label>
                                <input type="Email" name="email_t" class="form-control" id="inputEmail4" placeholder="Email" required>
                              </div>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="nama" class=" col-form-label">profesi</label>
                                <select name="profesi_id" id="" class="form-control" required>
                                  <option value="">--Pilih--</option>
                                  <?php foreach($prof as $data2):?>
                                  <option value="<?php echo $data2->id;?>"><?php echo $data2->nama_profesi;?></option>
                                  <?php endforeach;?>
                                </select>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="nama" class=" col-form-label">Rating</label> 
                                  <select name="rating" id="" class="form-control" required>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                  </select>
                              </div>
                              <div class="form-group col-md-12">
                                <label for="inputEmail4">Komentar</label>
                                <Textarea name="komentar" cols="30" rows="10"class="form-control"></Textarea>
                              </div>
                              <br>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                          </form>
                      </div>
                  </div>
               </div>
            </div>
          </div>   
            </div>
          </div>
        </div>
        <?php endforeach;?>
      </div>
     </div>
  </div>

  <div id="portfolio" class="our-portfolio section">
    <div class="portfolio-left-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/portfolio-left-dec.png" alt="">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2>Cari <em>Tempat Wisata</em> &amp; Kuliner <span>Depok</span></h2>
            <span>Wisata Depok</span>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-carousel owl-portfolio">
            <?php foreach($wisata_list as $data_wisata):?>
            <div class="item">
              <div class="thumb">
                <img src="data:image/jpeg;base64,<?php echo $data_wisata->img ?>" class="img-fluid" alt="Responsive image" alt="">
                <div class="hover-effect">
                  <div class="inner-content">
                    <a rel="sponsored" href="#" target="_parent"><h4><?php echo $data_wisata->nama_wisata ?></h4></a>
                    <span>
                      Bintang :<br>
                    <?php for($i=0; $i<$data_wisata->bintang; $i++ ){
                      echo '<i class = "fa fa-star"> </i>';
                    } ?>  
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach;?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="contact" class="contact-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <div class="section-heading">
            <h2>Daftarkan Tempat <em>Bisnis</em> atau <span>Witasa Kamu</span> Sekarang</h2>
          </div>
        </div>
        <div class="col-lg-5 align-self-center">
          <form id="contact" action="<?php echo base_url('index.php/Login/simpan_regist')?>" method="POST">
            <div class="row">
              <div class="col-lg-12">
                <fieldset>
                  <input type="name" name="nama" id="name" placeholder="Nama Kamu" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="surname" name="phone" id="surname" placeholder="Nomor Hp Kamu" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Email Kamu" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="Password" name="pass" id="website" placeholder="Password" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" id="form-submit" class="main-button">Save</button> 
                  <a href="<?php echo base_url()?>index.php/Login"  class="btn main-button">Sudah Memiliki akun <i class="fa fa-left"></i></a>
                </fieldset>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="contact-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/contact-dec.png" alt="">
    </div>
    <div class="contact-left-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/contact-left-dec.png" alt="">
    </div>
  </div>

  <div class="footer-dec">
    <img src="<?php echo base_url() ?>onix/assets/images/footer-dec.png" alt="">
  </div>
