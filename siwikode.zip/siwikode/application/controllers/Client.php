<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Client_model');
    }

    public function index()
    {
        $data['kategori_list'] = $this->Client_model->jenis_kuliner();
        $data['wisata_list'] = $this->Client_model->wisata();
        $this->load->view('uheader');
        $this->load->view('client/index', $data);
        $this->load->view('ufooter');
    }
    public function detail($id_wisata){
        
        $data['prof'] = $this->Client_model->profesi_get();
        $data['wisata_list'] = $this->Client_model->wisata();
        // $data['kategori_list'] = $this->Client_model->jenis_kuliner();
        $data['detail_list'] = $this->Client_model->getDetail($id_wisata);
        $data['komen_list'] = $this->Client_model->getkomenDetail($id_wisata);
        $this->load->view('client/detail', $data);
        $this->load->view('ufooter');
    }
    public function search()
    {
        // $data['kategori_list'] = $this->Client_model->jenis_kuliner();
        $search = $this->input->post('search');
        if($search == '' || $search == null){
            $data['wisata_list'] = $this->Client_model->wisata();
            $this->load->view('uheader');
            $this->load->view('client/index', $data);
            $this->load->view('ufooter');
        }else{
            $data['wisata_list'] = $this->Client_model->getSearch($search);
            $this->load->view('uheader');
            $this->load->view('client/index', $data);
            $this->load->view('ufooter');
        }

    }
    public function save_data()
    {
        $nama = $this->input->post('nama');
        $email = $this->input->post('email_t');
        $wisata_id = $this->input->post('wisata_id');
        $profesi_id = $this->input->post('profesi_id');
        $rating = $this->input->post('rating');
        $komentar = $this->input->post('komentar');
        $id_user = $this->session->userdata('id_user');

        $data = array(
            'nama' =>$nama,
            'email_t' =>$email,
            'wisata_id' =>$wisata_id,
            'profesi_id' =>$profesi_id,
            'rating' =>$rating,
            'komentar' => $komentar,
            'id_user' => $id_user
        );
        // echo json_encode($data);
        // exit();
        $val = $this->Client_model->save_data($data);
         echo "<meta http-equiv='refresh' content='0;url=".base_url()."index.php/Client/detail/".$wisata_id."'>";
        // redirect('Client/index');
    }
}