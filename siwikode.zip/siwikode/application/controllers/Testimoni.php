<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testimoni extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Testimoni_model');
    }

    public function index()
	{

        $role = $this->session->userdata('role');
        if($role == 'ADMIN'){
            $data['test'] =$this->Testimoni_model->getdataAll();
            $this->load->view('header');
            $this->load->view('testimoni/index',$data);
            $this->load->view('footer');
        }else{
            $id_user = $this->session->userdata('id_user');
            $data['test'] = $this->Testimoni_model->getdata($id_user);
            $this->load->view('header');
            $this->load->view('testimoni/index',$data);
            $this->load->view('footer');

        }
        
        //$this->load->view('tamplate');
	}
    public function create()
    {
        $data['prof'] = $this->Testimoni_model->getprofesi();
        $data['wisata'] = $this->Testimoni_model->getwisata();
        
        $this->load->view('header');
        $this->load->view('testimoni/form',$data);
        $this->load->view('footer');
    }

    public function save_data()
    {
        $nama = $this->input->post('nama');
        $email_t = $this->input->post('email');
        $wisata_id = $this->input->post('wisata_id');
        $profesi_id = $this->input->post('profesi_id');
        $rating = $this->input->post('rating');
        $komentar = $this->input->post('komentar');
        $id_user = $this->session->userdata('id_user');

        $data = array(
            'nama' =>$nama,
            'email_t' =>$email_t,
            'wisata_id' =>$wisata_id,
            'profesi_id' =>$profesi_id,
            'rating' =>$rating,
            'komentar' => $komentar,
            'id_user' => $id_user
        );
        // echo json_encode($data);
        // exit();
        $val = $this->Testimoni_model->save_data($data);
        redirect('Testimoni/index');
    }
    public function edit($id)
    {
        $data['edit_data']=$this->Testimoni_model->getDataEdit($id);
        $data['prof'] = $this->Testimoni_model->getprofesi();
        $data['wisata'] = $this->Testimoni_model->getwisata();
        
        $this->load->view('header');
        $this->load->view('testimoni/edit',$data);
        $this->load->view('footer');
    }

    public function save_data_edit()
    {
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $wisata_id = $this->input->post('wisata_id');
        $profesi_id = $this->input->post('profesi_id');
        $rating = $this->input->post('rating');
        $komentar = $this->input->post('komentar');
        $testimoni_id = $this->input->post('testimoni_id');

        $data = array(
            'nama' =>$nama,
            'email_t' =>$email,
            'wisata_id' =>$wisata_id,
            'profesi_id' =>$profesi_id,
            'rating' =>$rating,
            'komentar' => $komentar
        );

        $val= $this->Testimoni_model->update_data($testimoni_id,$data);
        // var_dump($testimoni_id);
        //   echo json_encode($val);
        // exit();
        redirect('Testimoni/index');
    }
    public function detail($id)
	{
        $data['detail'] = $this->Testimoni_model->getDataDetail($id);
        $this->load->view('header');
        $this->load->view('testimoni/detail',$data);
        $this->load->view('footer');
        //$this->load->view('tamplate');
	}
    public function delete($id)
    {
        $delete = $this->Testimoni_model->delete_data($id);
        redirect('Testimoni/index');
    }

}