<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wisata extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        $this->load->model('wisata_model','wm');
    } 

    public function index()
	{
        $role = $this->session->userdata('role');
        if($role == 'ADMIN'){
            $data['list_wisata'] =$this->wm->getdataAll();
            $this->load->view('header');
            $this->load->view('wisata/index',$data);
            $this->load->view('footer');
        }else{
            $id_user = $this->session->userdata('id_user');
            $data['list_wisata'] = $this->wm->getdata($id_user);
            $this->load->view('header');
            $this->load->view('wisata/index',$data);
            $this->load->view('footer');
        }

        //$this->load->view('tamplate');
	}
    public function create()
    {
        $data['list_jw'] = $this->wm->getjw();
        $data['list_jk'] = $this->wm->getjk();
        
        $this->load->view('header');
        $this->load->view('wisata/form',$data);
        $this->load->view('footer');
    }

    public function save()
    {

        $config['upload_path']          = './uploads/';
		$config['allowed_types']        = 'gif|jpg|png';
		// $config['max_size']             = 5000;
		// $config['max_width']            = 1024;
		// $config['max_height']           = 720;
		$this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('img'))
		{
				$error = array('error' => $this->upload->display_errors());
				$this->load->view('form_upload', $error);
		}else
		{
			$image_data = $this->upload->data();
			$imgdata = file_get_contents($image_data['full_path']);
			$file_encode=base64_encode($imgdata);


            $nama_wisata = $this->input->post('nama_wisata');
            $deskripsi = $this->input->post('deskripsi');
            $jw_id = $this->input->post('jenis_wisata_id');
            $fsa = $this->input->post('fasilitas');
            $bintang = $this->input->post('bintang');
            $kontak = $this->input->post('kontak');
            $alamat = $this->input->post('alamat');
            $latlong =$this->input->post('latlong');
            $web = $this->input->post('web');
            $email = $this->input->post('email');
            $jk_id = $this->input->post('jenis_kuliner_id');
            $id_user = $this->session->userdata('id_user');


            $data = array(
                'nama_wisata' =>$nama_wisata,
                'deskripsi' =>$deskripsi,
                'jenis_wisata_id' =>$jw_id,
                'fasilitas' =>$fsa,
                'bintang' =>$bintang,
                'kontak' =>$kontak,
                'alamat' =>$alamat,
                'latlong' =>$latlong,
                'web' =>$web,
                'email' =>$email,
                'jenis_kuliner_id' =>$jk_id,
                'id_user' => $id_user,
                'img' => $file_encode
            );
            // echo json_encode($data);
            // exit();
            $val = $this->wm->simpan($data);
            redirect('wisata/index');

        }

    }

    public function edit($id)
    {
        $data['idedit']=$this->wm->getEdit($id);
        $data['list_jw'] = $this->wm->getjw();
        $data['list_jk'] = $this->wm->getjk();
        
        $this->load->view('header');
        $this->load->view('wisata/edit',$data);
        $this->load->view('footer');
    }
    
    public function save_data_edit()
    {
        $id = $this->input->post('wisata_id');
        $nama_wisata = $this->input->post('nama_wisata');
        $deskripsi = $this->input->post('deskripsi');
        $jw_id = $this->input->post('jenis_wisata_id');
        $fsa = $this->input->post('fasilitas');
        $bintang = $this->input->post('bintang');
        $kontak = $this->input->post('kontak');
        $alamat = $this->input->post('alamat');
        $latlong = $this->input->post('latlong');
        $web = $this->input->post('web');
        $email = $this->input->post('email');
        $jk_id = $this->input->post('jenis_kuliner_id');

        $data = array(
            'nama_wisata' =>$nama_wisata,
            'deskripsi' =>$deskripsi,
            'jenis_wisata_id' =>$jw_id,
            'fasilitas' =>$fsa,
            'bintang' =>$bintang,
            'kontak' =>$kontak,
            'alamat' =>$alamat,
            'latlong' =>$latlong,
            'web' =>$web,
            'email' =>$email,
            'jenis_kuliner_id' =>$jk_id
        );
            
        //   echo json_encode($data);
        // exit();
        $val= $this->wm->update($id,$data);
        redirect('wisata/index');
    }

    public function detail($id)
	{
        $data['detail'] = $this->wm->getDetail($id);
        $this->load->view('header');
        $this->load->view('wisata/detail',$data);
        $this->load->view('footer');
        //$this->load->view('tamplate');
	}

    public function delete($id){

        
        $validate = $this->wm->validate($id);
        
	    if(count($validate) > 0){
            
            echo "<script>alert('Data Tidak Dapat Di Hapus ')</script>";
            echo "<meta http-equiv='refresh' content='0;url=".base_url()."index.php/wisata'>";
	        
	        
	    }else{
            // var_dump($validate);
            $this->wm->delete($id);
            redirect('wisata/index');
	      
	    }
        //pastikan role diperkenankan
        
        
    }

}