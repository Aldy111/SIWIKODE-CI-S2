<?php $nama = $this->session->userdata('nama');?>

<h1 class="mt-4">Dashboard</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Dashboard</li>
</ol>
<h4>SELAMAT DATANG</h4>
</br>
<h1><?php echo $nama?></h1>
<br>
<h6><b>Petunjuk :</b></h6>
<p>Silahkan input data wisata anda pada menu <b>Wisata</b>-> <b>Tambah Data</b> -> isi data dengan sesuai dan untuk mengisi location google maps ikuti tahap berikut ini:
    <li>Masuk Ke google maps.</li>
    <li>Cari lokasi bisnis atau wisata anda.</li>
    <img src="<?php echo base_url()?>public/image/1.png" width="500" alt="">
    <li>Kemudian tekan share dan pilih <b>Embed Map</b> kemudian <b>COPY HTML</b>, contoh link<br>.</li>
    <img src="<?php echo base_url()?>public/image/2.png" width="500" alt="">
    <img src="<?php echo base_url()?>public/image/3.png" width="500" alt="">
    
</p>

 


                   