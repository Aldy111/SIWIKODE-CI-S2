<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="<?php echo base_url() ?>onix/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <title>Siwikode</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url() ?>onix/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="<?php echo base_url() ?>public/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> -->



    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url()?>onix/assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo base_url()?>onix/assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="<?php echo base_url()?>onix/assets/css/animated.css">
    <link rel="stylesheet" href="<?php echo base_url()?>onix/assets/css/owl.css">
    
<!--

TemplateMo 565 Onix Digital

https://templatemo.com/tm-565-onix-digital

-->
  </head>
  <style>
    .fa-star{
      color:#ffc107;
    }
    .fa-search{
      color:#ffffff;
    }
    .detail-info{
      color:#ffffff;
    }
    .img-fluid-custom {
    max-width: 100%;
    height: 200px;
    }
    .img-fluid-custom-slide{
    max-width: 100%;
    height: 300px;
    }
  </style>


<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="<?php echo base_url()?>index.php/Client/Iindex" class="logo">
              <img src="<?php echo base_url()?>onix/assets/images/logo-D.png" width="100px">
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="#top">Home</a></li>
              <!-- <li class="scroll-to-section"><a href="#services">Jenis Wisata</a></li> -->
              <!-- <li class="scroll-to-section"><a href="#about">About</a></li> -->
                <!-- <li class="scroll-to-section"><a href="#video">Cari Temppat Wisata</a></li>  -->
              <li class="scroll-to-section"><a href="#portfolio">Tempat Wisata & Kuliner Depok</a></li>
              <li class="scroll-to-section"><div class="main-red-button-hover"><a href="#contact">Daftarkan Wisatamu</a></div></li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->