<div class="main-banner" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <div class="owl-carousel owl-banner">
                <div class="item header-text">
                  <h6>Welcome to Wisata Depok</h6>
                  <h2>Mau cari Tempat <em>Wisata</em> di <span>Depok</span>?</h2>
                  <p>Cari destinasi yang mau kamu kunjungi..</p>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#portfolio">Go!!!</a>
                    </div>
                  </div>
                </div>
                <div class="item header-text">
                  <h6>Kategiri Wisata</h6>
                  <h2>Lihat <em>Jenis Wisata</em> di <span>Depok</span></h2>
                  <p>Lihat beraneka ragam Kategori Wisata di Depok</p>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#services">Go!!! </a>
                    </div>
                  </div>
                </div>
                <!-- <div class="item header-text">
                  <h6>Video Tutorials</h6>
                  <h2>Watch <em>our videos</em> for your <span>projects</span></h2>
                  <p>Please <a rel="nofollow" href="https://www.paypal.me/templatemo" target="_blank">support us</a> a little via PayPal if this digital marketing HTML template is useful for you. Thank you.</p>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#video">Watch Videos</a>
                    </div>
                    <div class="call-button">
                      <a href="#"><i class="fa fa-phone"></i> 050-040-0320</a>
                    </div>
                  </div>
                </div> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- <div id="services" class="our-services section">
    <div class="services-right-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/services-right-dec.png" alt="">
    </div>
    <div class="container">
      <div class="services-left-dec">
        <img src="<?php echo base_url() ?>onix/assets/images/services-left-dec.png" alt="">
      </div>
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2>Kategori <em>Jenis Wisata</em> di <span>Depok</span></h2>
            <span>Jenis Wisata</span>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-carousel owl-services">
            <?php foreach($kategori_list as $kategori_data):?>
            <div class="item">
              <h4><?php echo $kategori_data->nama_jw?></h4>
              <div class="icon"><img src="<?php echo base_url() ?>onix/assets/images/service-icon-01.png" alt=""></div>
              <p></p>
            </div>
              <?php endforeach;?>
          </div>
        </div>
      </div>
    </div>
  </div> -->
  <div id="portfolio" class="our-portfolio section">
    <div class="portfolio-left-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/portfolio-left-dec.png" alt="">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2>Cari <em>Tempat Wisata</em> &amp; Kuliner <span>Depok</span></h2>
            <span>Wisata Depok</span>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-carousel owl-portfolio">
            <?php foreach($wisata_list as $data_wisata):?>
            <div class="item">
              <div class="thumb">
                <img src="data:image/jpeg;base64,<?php echo $data_wisata->img ?>" class="img-fluid-custom-slide" alt="Responsive image" alt="">
                <div class="hover-effect">
                  <div class="inner-content">
                    <a rel="sponsored" href="#" target="_parent"><h4><?php echo $data_wisata->nama_wisata ?></h4></a>
                    <span>
                      Bintang :<br>
                    <?php for($i=0; $i<$data_wisata->bintang; $i++ ){
                      echo '<i class = "fa fa-star"> </i>';
                    } ?>  
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach;?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="services" class="our-subscribe selection subscribe">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner-content">
            <div class="row">
              <div class="col-lg-10 offset-lg-1">
                <h2>Cari Tempat Wisata</h2>
                <form id="subscribe" action="<?php echo base_url('index.php/Client/search')?>" method="POST">
                  <input type="text" name="search" style="width:710px;" placeholder="Cari..">  
                  <button type="submit" id="form-submit" class="main-button "><i class="fa fa-search"></i> Cari</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
      <?php foreach($wisata_list as $data_wisata):?>
        <div class="col-lg-4 subscribe">
          <div class="inner-content">
            <div class="row">
              <div class="col-lg-10 offset-lg-1">
                <?php if(count($wisata_list) > 0):?>
                <img src="data:image/jpeg;base64,<?php echo $data_wisata->img ?>" class="img-fluid-custom" alt="Responsive image" alt="">
                <br>
                <h2 style ='font-size:17pt;'><?php echo $data_wisata->nama_wisata ?></h2>
               
                  <table class="detail-info">
                    <tr>
                      <td><b>Bintang</b> </td>
                      <td>                
                      <?php for($i=0; $i<$data_wisata->bintang; $i++ ){
                      echo '<i class = "fa fa-star"> </i>';
                      } ?>  
                      </td>
                    </tr>
                    <!--<tr>                  -->
                    <!--  <td><b>Alamat</b> </td>-->
                    <!--  <td><?php echo $data_wisata->alamat ?></td>-->
                    <!--</tr>                  -->
                    <tr>                  
                      <td>
                        <?php echo' <a href="'.base_url().'index.php/Client/detail/'.$data_wisata->id_wisata.'" class="btn btn-sm btn-info active" style="color:#ffffff;" role="button" aria-pressed="true"><i class="fa fa-search"></i> Detail</a>';?>
                      </td>
                    </tr>
                  </table>  
                  <?php else:?>
                    <h1>Ooops Tidak Ada data</h1>
                  <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach;?>
    </div>
    </div>
  </div>
    
  <!-- <div id="video" class="our-videos section">
    <div class="videos-left-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/videos-left-dec.png" alt="">
    </div>
    <div class="videos-right-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/videos-right-dec.png" alt="">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                <div class="col-lg-8">
                  <ul class="nacc">
                    <li class="active">
                      <div>
                        <div class="thumb">
                          <iframe width="100%" height="auto" src=https://www.youtube.com/embed/JynGuQx4a1Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                          <div class="overlay-effect">
                            <a href="#"><h4>Project One</h4></a>
                            <span>SEO &amp; Marketing</span>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <iframe width="100%" height="auto" src=https://www.youtube.com/embed/RdJBSFpcO4M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                          <div class="overlay-effect">
                            <a href="#"><h4>Second Project</h4></a>
                            <span>Advertising &amp; Marketing</span>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <iframe width="100%" height="auto" src=https://www.youtube.com/embed/ZlfAjbQiL78" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                          <div class="overlay-effect">
                            <a href="#"><h4>Project Three</h4></a>
                            <span>Digital &amp; Marketing</span>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <iframe width="100%" height="auto" src=https://www.youtube.com/embed/mx1WseE7-0Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                          <div class="overlay-effect">
                            <a href="#"><h4>Fourth Project</h4></a>
                            <span>SEO &amp; Advertising</span>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
                <div class="col-lg-4">
                  <div class="menu">
                    <div class="active">
                      <div class="thumb">
                        <img src="<?php echo base_url() ?>onix/assets/images/video-thumb-01.png" alt="">
                        <div class="inner-content">
                          <h4>Project One</h4>
                          <span>SEO &amp; Marketing</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="thumb">
                        <img src="<?php echo base_url() ?>onix/assets/images/video-thumb-02.png" alt="">
                        <div class="inner-content">
                          <h4>Second Project</h4>
                          <span>Advertising &amp; Marketing</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="thumb">
                        <img src="<?php echo base_url() ?>onix/assets/images/video-thumb-03.png" alt="Marketing">
                        <div class="inner-content">
                          <h4>Project Three</h4>
                          <span>Digital &amp; Marketing</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="thumb">
                        <img src="<?php echo base_url() ?>onix/assets/images/video-thumb-04.png" alt="SEO Work">
                        <div class="inner-content">
                          <h4>Fourth Project</h4>
                          <span>SEO &amp; Advertising</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>             
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div> -->
  <div id="contact" class="contact-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <div class="section-heading">
            <h2>Daftarkan Tempat <em>Bisnis</em> atau <span>Witasa Kamu</span> Sekarang</h2>
          </div>
        </div>
        <div class="col-lg-5 align-self-center">
          <form id="contact" action="<?php echo base_url('index.php/Login/simpan_regist')?>" method="POST">
            <div class="row">
              <div class="col-lg-12">
                <fieldset>
                  <input type="name" name="nama" id="name" placeholder="Nama Kamu" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="surname" name="phone" id="surname" maxlength="15" placeholder="Nomor Hp Kamu" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="email" id="email" maxlength="45" pattern="[^ @]*@[^ @]*" placeholder="Email Kamu" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="Password" name="pass" id="website" placeholder="Password" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" id="form-submit" class="main-button">Save</button> 
                  <a href="<?php echo base_url()?>index.php/Login"  class="btn main-button">Sudah Memiliki akun <i class="fa fa-left"></i></a>
                </fieldset>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="contact-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/contact-dec.png" alt="">
    </div>
    <div class="contact-left-dec">
      <img src="<?php echo base_url() ?>onix/assets/images/contact-left-dec.png" alt="">
    </div>
  </div>

  <div class="footer-dec">
    <img src="<?php echo base_url() ?>onix/assets/images/footer-dec.png" alt="">
  </div>
