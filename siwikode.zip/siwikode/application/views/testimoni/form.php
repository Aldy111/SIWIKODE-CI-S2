<?php $id_user = $this->session->userdata('id_user');?>
<h1>Form Testimoni</h1>
<?php echo form_open('Testimoni/save_data');?>
<div class="col-md-12">
  <div class="form-group row">
      <div class="col-8">
          <label for="nama" class=" col-form-label">Nama</label> 
          <input id="nama" name="nama" type="text" class="form-control">
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Email</label> 
          <input id="nama" name="email" type="text" class="form-control">
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Wisata</label>
          <select name="wisata_id" id="" class="form-control">
            <option value="">--Pilih--</option>
            <?php foreach($wisata as $data1):?>
            <option value="<?php echo $data1->id_wisata;?>"><?php echo $data1->nama_wisata;?></option>
            <?php endforeach;?>
          </select>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">profesi</label>
          <select name="profesi_id" id="" class="form-control">
            <option value="">--Pilih--</option>
            <?php foreach($prof as $data2):?>
            <option value="<?php echo $data2->id;?>"><?php echo $data2->nama_profesi;?></option>
            <?php endforeach;?>
          </select>
      </div>
      <div class="col-8">
          <label for="nama" class=" col-form-label">Rating</label> 
          <select name="rating" id="" class="form-control">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
      </div>
      <div class="col-8">
      <label for="nama" class=" col-form-label">komentar</label> 
      <textarea name="komentar" id="" cols="30" rows="10"class="form-control"></textarea>
      </div>
  </div> 
  <div class="form-group row">
    <div class="col-8">
        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</div>
<?php echo form_close()?>
