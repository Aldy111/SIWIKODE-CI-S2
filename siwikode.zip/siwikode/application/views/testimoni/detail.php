
<?php echo form_open('Testimoni/save_data_edit');?>
<h1 class="mt-4">Detail Testimoni</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Detail Testimoni</li>
</ol>
<?php foreach($detail as $data):?>
  <div class="col-4">
    <table class="table ">
    <tr>
    <td>Nama  </td><td>:</td>
    <td><?php echo $data->nama?></td>
    </tr>
    <tr>
    <td>Email  </td><td>:</td>
    <td><?php echo $data->email_t?></td>
    </tr>
    <tr>
    <td>Wisata  </td><td>:</td>
    <td><?php echo $data->nama_wisata?></td>
    </tr>
    <tr>
    <td>Profesi  </td><td>:</td>
    <td><?php echo $data->nama_profesi?></td>
    </tr>
    <tr>
    <td>Rating  </td><td>:</td>
    <td><?php echo $data->rating?></td>
    </tr>
    <tr>
    <td>Komentar  </td><td>:</td>
    <td><?php echo $data->komentar?></td>
    </tr>
    </table>
  </div>
  </div>
  <?php endforeach;?>

<?php echo form_close()?>
