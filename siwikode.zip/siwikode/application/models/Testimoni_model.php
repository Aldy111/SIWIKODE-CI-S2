<?php
class Testimoni_model extends CI_Model{
    
    public function getdata($id_user)
    {
        $this->db->select('*');
        $this->db->from('testimoni');
        $this->db->where('id_user',$id_user);
        $query= $this->db->get();
        return $query->result();
    }
    public function getdataAll()
    {
        $this->db->select('*');
        $this->db->from('testimoni');
        $query= $this->db->get();
        return $query->result();
    }

    public function getDataDetail($id)
    {
        $this->db->select('*');
        $this->db->from('testimoni');
        $this->db->join('wisata', 'wisata.id_wisata = testimoni.wisata_id');
        $this->db->join('profesi', 'profesi.id = testimoni.profesi_id');
        $this->db->where('testimoni_id',$id);
        $query = $this->db->get();
        return $query->result();
    }
    public function getprofesi()
    {
        $query = $this->db->get('profesi');
        return $query->result();
    }
    public function getwisata()
    {
        $query = $this->db->get('wisata');
        return $query->result();
    }
    public function save_data($data)
    {
        $this->db->insert('testimoni', $data);
    }
    public function getDataEdit($id)
    {
        $this->db->select('*');
        $this->db->from('testimoni');
        $this->db->where('testimoni_id',$id);
        return $this->db->get()->result();
    }
    public function update_data($testimoni_id,$data)
    {
        $this->db->where('testimoni_id', $testimoni_id);
        $this->db->update('testimoni', $data); 
    }
    public function delete_data($id)
    {
        $this->db->where('testimoni_id', $id);
        $this->db->delete('testimoni'); 
    }
}