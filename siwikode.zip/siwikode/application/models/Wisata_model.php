<?php
class Wisata_model extends CI_Model{

    public function getdata($id_user)
    {
        $this->db->select('*');
        $this->db->from('wisata');
        $this->db->where('id_user',$id_user);
        $query= $this->db->get();
        return $query->result();
    }
    public function getdataAll()
    {
        $this->db->select('*');
        $this->db->from('wisata');
        $query= $this->db->get();
        return $query->result();
    }
    public function findById($id){
        //SELECT * FROM jenis_kuliner WHERE id=1;
        $query = $this->db->get_where('wisata', array('id' => $id));
        return $query->row();
    }
    public function getjw()
    {
        $query = $this->db->get('jenis_wisata');
        return $query->result();
    }
    public function getjk()
    {
        $query = $this->db->get('jenis_kuliner');
        return $query->result();
    }
    
    public function simpan($data)
    {
        $this->db->insert('wisata', $data);
    }

    public function getEdit($id)
    {
        $this->db->select('*');
        $this->db->from('wisata');
        $this->db->where('id_wisata',$id);
        return $this->db->get()->result();
    }

    public function update($id_wisata,$data)
    {
        $this->db->where('id_wisata', $id_wisata);
        $this->db->update('wisata', $data); 
    }

    public function delete($id)
    {
        $this->db->where('id_wisata', $id);
        $this->db->delete('wisata'); 
    }

    function validate($id){
        $this->db->select('*');
        $this->db->from('wisata');
        $this->db->join('testimoni','testimoni.wisata_id = wisata.id_wisata');
        $this->db->where('id_wisata',$id);
        $result = $this->db->get();
        return $result->result();
    }

    public function getDetail($id)
    {
        $this->db->select('*');
        $this->db->from('wisata');
        $this->db->join('jenis_wisata', 'jenis_wisata.id = wisata.jenis_wisata_id');
        $this->db->join('jenis_kuliner', 'jenis_kuliner.id = wisata.jenis_kuliner_id');
        $this->db->where('id_wisata',$id);
        $query = $this->db->get();
        return $query->result();
    }

}