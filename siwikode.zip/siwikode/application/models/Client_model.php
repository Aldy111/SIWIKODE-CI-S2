<?php
class Client_model extends CI_Model{

    public function jenis_kuliner()
    {
        $this->db->select('*');
        $this->db->from('jenis_wisata');
        $query= $this->db->get();
        return $query->result();
        return $sql->result();
    }
    public function wisata()
    {
        $this->db->select('*');
        $this->db->from('wisata');
        $this->db->join('jenis_wisata', 'jenis_wisata.id = wisata.jenis_wisata_id');
        $this->db->join('jenis_kuliner', 'jenis_kuliner.id = wisata.jenis_kuliner_id');
        // $this->db->join('testimoni', 'jenis_wisata.id = wisata.jenis_wisata_id');
        // $this->db->group_by("id_wisata");
        $query = $this->db->get();
        return $query->result();
    }
    public function getSearch($search)
    {
        $this->db->select('*');
        $this->db->from('wisata');
        $this->db->join('jenis_wisata', 'jenis_wisata.id = wisata.jenis_wisata_id');
        $this->db->join('jenis_kuliner', 'jenis_kuliner.id = wisata.jenis_kuliner_id');
        $this->db->join('testimoni', 'testimoni.wisata_id = wisata.id_wisata','left');
        $this->db->like('nama_wisata',$search);
        $this->db->or_like('nama_jk',$search);
        $this->db->or_like('nama_jw',$search);
        $this->db->group_by("id_wisata");
        $query = $this->db->get();
        return $query->result();
    }
    public function getDetail($id_wisata)
    {
        $this->db->select('*');
        $this->db->from('wisata');
        $this->db->join('jenis_wisata', 'jenis_wisata.id = wisata.jenis_wisata_id');
        $this->db->join('jenis_kuliner', 'jenis_kuliner.id = wisata.jenis_kuliner_id');
        $this->db->where('id_wisata',$id_wisata);
        $this->db->group_by("id_wisata");
        $query = $this->db->get();
        return $query->result();
    }
    public function getkomenDetail($id_wisata)
    {
        $this->db->select('*');
        $this->db->from('testimoni');
        $this->db->join('wisata', 'testimoni.wisata_id = wisata.id_wisata');
        $this->db->join('profesi', 'testimoni.profesi_id = profesi.id');
        $this->db->where('id_wisata',$id_wisata);
        $query = $this->db->get();
        return $query->result();
    }
    public function profesi_get()
    {
        $sql = $this->db->get('profesi');
        return $sql->result();
    }
    public function save_data($data)
    {
        $this->db->insert('testimoni',$data);
    }
    
}